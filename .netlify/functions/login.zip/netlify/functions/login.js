// netlify/functions/login.js

const jwt = require('jsonwebtoken');

const { JWT_SECRET } = process.env;

exports.handler = async (event) => {
    if (event.httpMethod !== 'POST') {
        return { statusCode: 405, body: JSON.stringify({ error: 'Method Not Allowed' }) };
    }

    if (!JWT_SECRET) {
        console.error("FATAL ERROR: JWT_SECRET environment variable is not set.");
        return { statusCode: 500, body: JSON.stringify({ error: 'Server configuration error.' }) };
    }

    try {
        const { username, password } = JSON.parse(event.body);

        if (username === 'SpecsGamerz' && password === '1919') {
            const user = {
                id: 'admin-001',
                username: 'SpecsGamerz',
                role: 'admin',
            };
            
            const token = jwt.sign(
                { userId: user.id, username: user.username, role: user.role },
                JWT_SECRET,
                { expiresIn: '8h' }
            );
            
            return {
                statusCode: 200,
                body: JSON.stringify({ 
                    message: 'Admin login successful!', 
                    token, 
                    user 
                }),
            };
        }
        
        return {
            statusCode: 401,
            body: JSON.stringify({ error: 'Invalid username or password' }),
        };

    } catch (error) {
        console.error("Login function error:", error);
        return { 
            statusCode: 500, 
            body: JSON.stringify({ error: 'An internal server error occurred.' }) 
        };
    }
};